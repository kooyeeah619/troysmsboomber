import express from "express";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
app.use(express.json({ limit: "10kb" }));
app.use(express.static("public"));

const required = ["APP_TOKEN", "SEMAPHORE_API_KEY", "SEMAPHORE_SENDER_NAME"];
const missing = required.filter(k => !process.env[k]);
const allowed = new Set((process.env.ALLOWED_RECIPIENTS || "")
  .split(",").map(x => x.trim()).filter(Boolean));

app.use("/api/send", rateLimit({
  windowMs: 60_000, limit: 3, standardHeaders: true, legacyHeaders: false
}));

app.get("/api/status", (_req, res) => {
  res.json({ configured: missing.length === 0 && allowed.size > 0,
    missing: missing.filter(k => k !== "APP_TOKEN" || !process.env.APP_TOKEN),
    approvedRecipients: allowed.size });
});

function toSemaphoreNumber(e164) {
  // Semaphore's Philippine examples use local 09xxxxxxxxx format.
  return e164.startsWith("+63") ? "0" + e164.slice(3) : e164;
}

app.post("/api/send", async (req, res) => {
  if (missing.length || allowed.size === 0)
    return res.status(503).json({ error: "Server is not configured. Administrator setup is incomplete." });
  if (req.get("authorization") !== `Bearer ${process.env.APP_TOKEN}`)
    return res.status(401).json({ error: "Unauthorized." });

  const to = String(req.body?.to || "").trim();
  const message = String(req.body?.body || "").trim();
  if (!/^\+639\d{9}$/.test(to))
    return res.status(400).json({ error: "Enter a Philippine mobile number in +639XXXXXXXXX format." });
  if (!allowed.has(to))
    return res.status(403).json({ error: "This number is not on the consent-approved recipient list." });
  if (!message || message.length > 500)
    return res.status(400).json({ error: "Message must be 1–500 characters." });

  try {
    const form = new URLSearchParams({
      apikey: process.env.SEMAPHORE_API_KEY,
      number: toSemaphoreNumber(to),
      message,
      sendername: process.env.SEMAPHORE_SENDER_NAME
    });
    const response = await fetch("https://api.semaphore.co/api/v4/messages", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form
    });
    const data = await response.json();
    if (!response.ok || (Array.isArray(data) && data[0]?.status === "Failed") ||
        (data && !Array.isArray(data) && data.status === "error")) {
      console.error("Semaphore rejected request:", JSON.stringify(data));
      return res.status(502).json({ error: "Semaphore did not accept the SMS. Check your API key, credits, sender name and account status." });
    }
    const item = Array.isArray(data) ? data[0] : data;
    res.json({ ok: true, messageId: item?.message_id ?? null, status: item?.status ?? "accepted" });
  } catch (e) {
    console.error("Semaphore request failed:", e.message);
    res.status(502).json({ error: "Could not reach Semaphore. Try again later." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`SMS-B listening on port ${port}`));
