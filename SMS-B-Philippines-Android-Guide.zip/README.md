# SMS-B Philippines — consent-based Android app starter

This is an installable Progressive Web App (PWA) with a Node.js backend connected to the Philippine SMS provider Semaphore. It sends **one SMS per user action**, only to a small allowlist of contacts who explicitly opted in. It is not an SMS bomber or unsolicited bulk sender.

## 1. Create your Semaphore account
1. Open https://semaphore.co/ and create an account.
2. Verify/activate the account and check the dashboard for your API key.
3. Add credits only after reviewing the current rates in your account.
4. Register a legitimate sender name for your business/use case if required. Semaphore says sender names are up to 11 alphanumeric characters and approval can take up to 5 business days. See https://semaphore.co/faq.
5. Keep your API key private. Never paste it into the website's HTML or share it in chat.

## 2. Configure the server
1. Install Node.js 20 or newer on a computer/server.
2. Extract this folder and open a terminal in it.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `APP_TOKEN` to a long random secret.
6. Set `SEMAPHORE_API_KEY` and `SEMAPHORE_SENDER_NAME` using the values from your Semaphore account.
7. Set `ALLOWED_RECIPIENTS` to the international-format numbers of people who explicitly agreed to receive messages, e.g. `+639171234567`. Do not use example numbers.
8. Run `npm start`, then open `http://localhost:3000`.

## 3. Deploy online
1. Push the project to a private GitHub repository.
2. Create a Node web service on Render (or another Node host).
3. Build command: `npm install`; start command: `npm start`.
4. Add the variables from `.env.example` in the host's Environment settings. Do not upload `.env`.
5. Deploy. Use the HTTPS URL provided by your host.

## 4. Install on Android
1. Open the HTTPS website URL in Chrome on your Android phone.
2. Tap Chrome's ⋮ menu.
3. Choose **Install app** or **Add to Home screen**.
4. Launch SMS-B from your home screen.

This is a PWA installation guide, not a Play Store APK.

## Important
- The backend converts `+639...` recipients to the local `09...` format shown in Semaphore's API examples.
- The app enforces one recipient per request, a 3-requests-per-minute limit, and a manually maintained consent allowlist.
- Keep API credentials on the server only.
- Maintain consent records, honor opt-outs immediately, and comply with Semaphore's terms and applicable Philippine privacy/telecom rules.
- Provider acceptance/queueing is not proof that a message reached the handset. Check delivery status in the Semaphore dashboard/API.
- Before public launch, add administrator login, audit logs, spending limits and stronger account controls.
